package com.example.myapplication.template

data class InfoTitleDescription(
    val title: String = "",
    val description: String? = "-"
)